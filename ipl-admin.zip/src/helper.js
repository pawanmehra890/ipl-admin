export const zeroHourTimestampFromTimestampHelper = (dateTimestamp) => {
    // Setting Zero Hours
    let date = new Date(dateTimestamp);
  
    // Set Zero Hours
    date.setHours(0, 0, 0, 0);
  
    // Date Timestamp
    let zeroHourDateTimestamp = date.getTime();
  
    // Return Value
    return zeroHourDateTimestamp;
  };