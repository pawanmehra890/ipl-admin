import {
  Navigate,
  Route,
  BrowserRouter as Router,
  Routes,
  useNavigate,
} from "react-router-dom";
import Dashboard from "./screens/Dashboard";
import Login from "./screens/Login";
import { useEffect } from "react";
import CrossCityList from "./screens/crosscityuserlist";
import RepeatedUser from "./screens/repeateduser";
import Uniqueuser from "./screens/uniqueuser";
import UniqueuserRepeated from "./screens/uniqueuserepeated";
import CityUniqueuser from "./screens/Cityuniqueuser";
import CityUniqueuserRepeated from "./screens/Cityuniqueuserepeated";
import Prematchuserlist from "./screens/prematchuser";
import Onlylivematch from "./screens/onlylivenatch ";
import BothPrematchuserlist from "./screens/bothprematchuserandlive";
import Weeklyleaderboard from "./screens/weekyleaderboard";
import TopPerformingStateOverall from "./screens/TopPerformingStateOverall";

function App() {
  const navigate=useNavigate()

  useEffect(() => {
    // Check authentication status
    const checkAuth = () => {
      const userData = localStorage.getItem('accessToken');

      
      if (userData) {
        try {
          // Validate token
          const parts = userData.split('.');
          const decodedPayload = atob(parts[1]);
          const parsedPayload = JSON.parse(decodedPayload);
          const { exp } = parsedPayload;
          const currentTime = Math.floor(Date.now() / 1000);
           console.log(exp,'exp')
          if (exp && currentTime >= exp) {
            // Token expired
            localStorage.clear();
            navigate('/')
          } else {
            // Valid token
          }
        } catch (error) {
          // Invalid token format
          localStorage.clear();
        }
      } else {
      }
      
      // Authentication check complete
    };
    
    checkAuth();
  }, []);

  return (
    
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />

        <Route path="/crosscityuserlist" element={<CrossCityList />} />
        <Route path="/repeatuser" element={<RepeatedUser />} />
        <Route path="/topstateuniqueuser" element={<Uniqueuser />} />
        <Route path="/topstateuniqueuserRepeated" element={<UniqueuserRepeated />} />
        <Route path="/topCityuniqueuser" element={<CityUniqueuser />} />
        <Route path="/CityUniqueuserRepeated" element={<CityUniqueuserRepeated />} />
        <Route path="/prematchuserlist" element={<Prematchuserlist />} />
        <Route path="/Onlylivematch" element={<Onlylivematch />} />
        <Route path="/BothPreAndLiveMatch" element={<BothPrematchuserlist />} />
        <Route path="/WeeklyLeaderboard" element={<Weeklyleaderboard />} />
        <Route path="/TopPerformingStateOverall" element={<TopPerformingStateOverall />} />


        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
  );
}

export default App;
