import { createSlice } from "@reduxjs/toolkit";

// Get initial role from localStorage
const initialRole = Number(localStorage.getItem("role")) || 1;

const roleSlice = createSlice({
  name: "role",
  initialState: { value: initialRole },
  reducers: {
    setRole: (state, action) => {
      state.value = action.payload;
      localStorage.setItem("role", action.payload); // Persist to localStorage
    },
  },
});

export const { setRole } = roleSlice.actions;
export default roleSlice.reducer;
