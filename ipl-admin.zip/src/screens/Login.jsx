import { baseurl } from "@/auth/baseurl";
import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post(
        `${baseurl}Authentication/api/admin/login-admin`,
        formData,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      const { accessToken, refreshToken } = response.data.result;

      // Store tokens in localStorage
      localStorage.setItem("accessToken", accessToken);
      localStorage.setItem("refreshToken", refreshToken);

      console.log("Tokens saved. Redirecting to dashboard...");

      navigate("/dashboard");
    } catch (error) {
      console.error("Error during login:", error);
      alert("Invalid credentials or server error");
    }
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gradient-to-br from-black to-slate-900 text-slate-100 relative">
      <div className="absolute inset-0 bg-black opacity-30" />
      <form
        onSubmit={handleSubmit}
        className="relative z-10 backdrop-blur-md bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50 shadow-lg w-full max-w-sm"
      >
        <h2 className="text-2xl font-bold mb-6 text-center bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
          KF Predict & Win
        </h2>

        <div className="mb-4">
          <label
            htmlFor="username"
            className="block text-sm font-medium text-slate-300"
          >
            Username
          </label>
          <input
            type="text"
            name="username"
            id="username"
            value={formData.username}
            onChange={handleChange}
            required
            className="mt-1 w-full px-4 py-2 bg-white/5 border border-slate-600 text-slate-100 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500"
          />
        </div>

        <div className="mb-6">
          <label
            htmlFor="password"
            className="block text-sm font-medium text-slate-300"
          >
            Password
          </label>
          <input
            type="password"
            name="password"
            id="password"
            value={formData.password}
            onChange={handleChange}
            required
            className="mt-1 w-full px-4 py-2 bg-white/5 border border-slate-600 text-slate-100 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <button
          type="submit"
          className="w-full bg-cyan-600 hover:bg-cyan-700 cursor-pointer text-white py-2 px-4 rounded-md transition"
        >
          Login
        </button>
      </form>
    </div>
  );
};

export default Login;
