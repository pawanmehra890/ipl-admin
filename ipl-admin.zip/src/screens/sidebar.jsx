import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Command, Cross, LogOutIcon, User } from "lucide-react";
import { Button } from "@/components/ui/button";

const Sidebar = () => {
  const navigate = useNavigate();

  const handlelogout = () => {
    localStorage.clear();
    navigate('/');
  };

  return (
    <div className="col-span-12 md:col-span-4 lg:col-span-3">
      <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm h-[100vh]">
        <CardContent className="p-4">
          <nav className="space-y-2">
            <NavItem 
              icon={User} 
              label="User List" 
              to="/dashboard" 
              active={location.pathname === '/dashboard'}
            />  
            
            <NavItem 
            icon={Cross} 
            label="Cross City User List" 
            to="/crosscityuserlist" 
            active={location.pathname === '/crosscityuserlist'}
          />


            <NavItem 
              icon={Command} 
              label="Repeat User List" 
              to="/repeatuser" 
              active={location.pathname === '/repeatuser'}
            />
             <NavItem 
              icon={Command} 
              label="Top State By Unique User" 
              to="/topstateuniqueuser" 
              active={location.pathname === '/topstateuniqueuser'}
            />
              <NavItem 
              icon={Command} 
              label="Top State By Repeat User" 
              to="/topstateuniqueuserRepeated" 
              active={location.pathname === '/topstateuniqueuserRepeated'}
            />
             <NavItem 
              icon={Command} 
              label="Top City By Unique User" 
              to="/topCityuniqueuser" 
              active={location.pathname === '/topCityuniqueuser'}
            />
   <NavItem 
              icon={Command} 
              label="Top City By Repeat User" 
              to="/CityUniqueuserRepeated" 
              active={location.pathname === '/CityUniqueuserRepeated'}
            />

<NavItem 
              icon={Command} 
              label="Only Prematch Prediction User List" 
              to="/prematchuserlist" 
              active={location.pathname === '/prematchuserlist'}
            />

<NavItem 
              icon={Command} 
              label=" Only Live Match User List" 
              to="/Onlylivematch" 
              active={location.pathname === '/Onlylivematch'}
            />

<NavItem 
              icon={Command} 
              label="Both Pre And Live Match" 
              to="/BothPreAndLiveMatch" 
              active={location.pathname === '/BothPreAndLiveMatch'}
            />
            <NavItem 
              icon={Command} 
              label="Weekly Leaderboard" 
              to="/WeeklyLeaderboard
" 
              active={location.pathname === '/WeeklyLeaderboard'}
            />
       

       <NavItem 
              icon={Command} 
              label="Top Performing State Overall" 
              to="/TopPerformingStateOverall
" 
              active={location.pathname === '/TopPerformingStateOverall'}
            />

       
            {/* <NavItem 
              icon={Command} 
              label="Dashboard" 
              to="/dashboard" 
              active={location.pathname === '/dashboard'}
            /> */}

            <div className="w-full flex justify-start items-end ml-[14px] h-[40vh] ">
              <button 
                className="text-slate-400 flex gap-2 items-center hover:text-slate-100 cursor-pointer"  
                onClick={handlelogout}
              >
                <LogOutIcon className="mr-2 h-4 w-4"/> 
                Logout
              </button>
            </div>
          </nav>
        </CardContent>
      </Card>
    </div>
  );
};

function NavItem({ icon: Icon, label, to, active }) {
  return (
    <Link to={to}>
      <Button
        variant="ghost"
        className={`w-full justify-start text-wrap  ${
          active
            ? "bg-slate-800/70 text-cyan-400"
            : "text-slate-400 hover:text-slate-100"
        }`}
      >
        <Icon className="mr-2 h-4 w-4" />
        {label}
      </Button>
    </Link>
  );
}

export default Sidebar;