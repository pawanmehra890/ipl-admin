import { useState } from 'react';

const DateRangeFilter = () => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [appliedFilter, setAppliedFilter] = useState(null);

  const handleApply = () => {
    if (!startDate || !endDate) {
      alert('Please select both start and end dates');
      return;
    }

    const startTimestamp = new Date(startDate).getTime();
    const endTimestamp = new Date(endDate).getTime();

    setAppliedFilter({
      startDate,
      endDate,
      startTimestamp,
      endTimestamp,
      appliedAt: new Date().toISOString()
    });
  };

  const handleReset = () => {
    setStartDate('');
    setEndDate('');
    setAppliedFilter(null);
  };

  return (
    <div className="max-w-2xl  mt-5 p-2 rounded-lg shadow-md">
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-2 justify-center items-center">
        <div>
          <label htmlFor="startDate" className="block text-sm font-medium text-white mb-1">
            Start Date
          </label>
          <input
            type="date"
            id="startDate"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full px-3 py-2 border  border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <div>
          <label htmlFor="endDate" className="block text-sm font-medium text-white mb-1">
            End Date
          </label>
          <input
            type="date"
            id="endDate"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full px-3 py-2 border  border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        <button
          onClick={handleApply}
          className="px-4 max-h-max mt-5 max-w-max py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          Apply Filter
        </button>
      </div>
{/*       
      <div className="flex space-x-3 mb-6">
      
        
        <button
          onClick={handleReset}
          className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
        >
          Reset
        </button>
      </div> */}
      
      {/* {appliedFilter && (
        <div className="p-4 bg-gray-50 rounded-md border border-gray-200">
          <h3 className="font-medium text-gray-800 mb-2">Applied Filter Details</h3>
          <div className="space-y-1 text-sm text-gray-600">
            <p><span className="font-medium">Start Date:</span> {appliedFilter.startDate}</p>
            <p><span className="font-medium">Start Timestamp:</span> {appliedFilter.startTimestamp}</p>
            <p><span className="font-medium">End Date:</span> {appliedFilter.endDate}</p>
            <p><span className="font-medium">End Timestamp:</span> {appliedFilter.endTimestamp}</p>
            <p><span className="font-medium">Applied At:</span> {appliedFilter.appliedAt}</p>
          </div>
        </div>
      )} */}
    </div>
  );
};

export default DateRangeFilter;