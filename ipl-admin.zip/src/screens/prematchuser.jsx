"use client";

import axios from "axios";
import {
  Activity,
  BarChart3,
  Command,
  Download,
  HardDrive,
  LineChart,
  Loader,
  LogOutIcon,
  Search,
  Users,
  Wifi,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import * as XLSX from 'xlsx';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import moment from "moment";
import {baseurl} from "@/auth/baseurl";
import { useNavigate } from "react-router-dom";
import DateRangeFilter from "./datefilter";
import { zeroHourTimestampFromTimestampHelper } from "@/helper";
import Sidebar from "./sidebar";

export default function Prematchuserlist() {
  const navigate=useNavigate()
  const startDataTimeStamp=zeroHourTimestampFromTimestampHelper(Date.now())
  const endDateTimestamp=startDataTimeStamp+86399*1000
  const [startDate, setStartDate] = useState(startDataTimeStamp);
  const [endDate, setEndDate] = useState(endDateTimestamp);
  const [theme, setTheme] = useState("dark");
  const [memoryUsage, setMemoryUsage] = useState(68);
  const [networkStatus, setNetworkStatus] = useState(92);
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [totalUsers, setTotalUsers] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchTimeout, setSearchTimeout] = useState(null);
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState([]);

  const token=localStorage.getItem('accessToken')
  // Regular fetch for the current page

   
  


  const fetchUsers = async (startDate,endDate) => {
    setLoading(true);
    try {

     

      const response = await axios.get(
        `${baseurl}Authentication/api/admin/only-pre-match-prediction-user-list`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      // Extract data from the result array
      if (response.data && response.data.result) {
        const fetchedUsers = response.data.result;
        setUsers(fetchedUsers);
        setFilteredUsers(fetchedUsers);

        // Set total users count for the metric card
        setTotalUsers(fetchedUsers.length * 3); // Multiplying by 3 to simulate a larger dataset

        // Since we don't have totalPages info, we'll estimate based on data length
        // If we get fewer items than requested, we're likely on the last page
        // if (response.data.result.length < itemsPerPage) {
        //   setTotalPages(currentPage);
        // } else {
        //   // Otherwise, assume there might be more pages
        //   setTotalPages(Math.max(5, currentPage + 2)); // Setting at least 5 pages for demo
        // }
      } else {
        setUsers([]);
        setFilteredUsers([]);
        // setTotalPages(1);
        setTotalUsers(0);
      }

      setError(null);
    } catch (err) {
      console.error("Error fetching users:", err);
      setError("Failed to fetch users. Please try again later.");
      setUsers([]);
      setFilteredUsers([]);
    } finally {
      setLoading(false);
    }
  };

  // Search across all pages
  // const searchAllPages = async (term) => {
  //   if (!term.trim()) {
  //     setIsSearching(false);
  //     fetchUsers(currentPage);
  //     return;
  //   }

  //   setIsSearching(true);
  //   setLoading(true);

  //   try {
  //     // Start with a reasonable number of pages to search
  //     const maxPagesToSearch = 10;
  //     let foundUsers = [];
  //     let userFoundOnPage = null;

  //     // Search through pages until we find the user or reach the max
  //     for (let page = 1; page <= maxPagesToSearch; page++) {
  //       const response = await axios.get(
  //         `${baseurl}Authentication/api/admin/user-list?startDateTimestamp=${startDate}&endDateTimestamp=${endDate}`,
  //         {
  //           headers: {
  //             Authorization: `Bearer ${token}`,
  //           },
  //         }
  //       );

  //       if (response.data && response.data.result) {
  //         const pageUsers = response.data.result;

  //         // Check if any user on this page matches the search term
  //         const matchingUsers = pageUsers.filter((user) =>
  //           user.name.toLowerCase().includes(term.toLowerCase())
  //         );

  //         if (matchingUsers.length > 0) {
  //           foundUsers = matchingUsers;
  //           userFoundOnPage = page;
  //           break; // Stop searching once we find matching users
  //         }

  //         // If we get fewer items than requested, we've reached the last page
  //         if (pageUsers.length < itemsPerPage) {
  //           break;
  //         }
  //       } else {
  //         break; // No more results
  //       }
  //     }

  //     if (foundUsers.length > 0 && userFoundOnPage) {
  //       // Navigate to the page where users were found
  //       setCurrentPage(userFoundOnPage);
  //       setFilteredUsers(foundUsers);
  //       setUsers(foundUsers);
  //       setSearchResults(foundUsers);
  //     } else {
  //       // No matching users found
  //       setFilteredUsers([]);
  //       setSearchResults([]);
  //     }

  //     setError(null);
  //   } catch (err) {
  //     console.error("Error searching users:", err);
  //     setError("Failed to search users. Please try again later.");
  //     setFilteredUsers([]);
  //     setSearchResults([]);
  //   } finally {
  //     setLoading(false);
  //   }
  // };


  const getAlloverAllDashboardDetails = async (startDate,endDate) => {
    try {
        const response = await axios.get(
            `${baseurl}Authentication/api/admin/overall-details?startDateTimestamp= ${startDate}&endDateTimestamp=${endDate}`,
            {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
               
            }
        ); 
        console.log(response,'response')
        setNetworkStatus(response?.data?.result)


    } catch (err) {
        console.error('Error fetching dashboard details:', err);
        throw err; // Re-throw the error to handle it in the calling function
    }
};


  // Load initial data

  

  // Handle search

  const canvasRef = useRef(null);

  // Generate pagination buttons
  const renderPaginationButtons = () => {
    const buttons = [];

    // Calculate which page numbers to show
    let startPage = Math.max(1, currentPage - 1);
    const endPage = Math.min(totalPages, startPage + 2);

    // Adjust if we're at the end
    if (endPage - startPage < 2) {
      startPage = Math.max(1, endPage - 2);
    }

    // First page
    if (startPage > 1) {
      buttons.push(
        <Button
          key="1"
          variant="outline"
          size="icon"
          onClick={() => setCurrentPage(1)}
          className={`rounded-full w-20 h-8 border-slate-700 ${
            currentPage === 1
              ? "text-cyan-500"
              : "text-slate-300 hover:bg-slate-700/50"
          }`}
        >
          1
        </Button>
      );

      // Ellipsis if needed
      if (startPage > 2) {
        buttons.push(
          <span key="ellipsis1" className="text-slate-400 px-1">
            ...
          </span>
        );
      }
    }

    // Page numbers
    for (let i = startPage; i <= endPage; i++) {
      buttons.push(
        <Button
          key={i}
          variant="outline"
          size="icon"
          onClick={() => setCurrentPage(i)}
          className={`rounded-full w-8 h-8 border-slate-700 ${
            currentPage === i
              ? "text-cyan-500"
              : "text-slate-300 hover:bg-slate-700/50"
          }`}
        >
          {i}
        </Button>
      );
    }

    // Ellipsis if needed
    if (endPage < totalPages - 1) {
      buttons.push(
        <span key="ellipsis2" className="text-slate-400 px-1">
          ...
        </span>
      );
    }

    // Last page
    if (endPage < totalPages) {
      buttons.push(
        <Button
          key={totalPages}
          variant="outline"
          size="icon"
          onClick={() => setCurrentPage(totalPages)}
          className={`rounded-full w-8 h-8 border-slate-700 ${
            currentPage === totalPages
              ? "text-cyan-500"
              : "text-slate-300 hover:bg-slate-700/50"
          }`}
        >
          {totalPages}
        </Button>
      );
    }

    return buttons;
  };


  const filteredDataPagination = useMemo(() => {
    if (!searchTerm) return filteredUsers;
    
    const term = searchTerm.toLowerCase();
    return filteredUsers.filter(item => 
      item.name.toLowerCase().includes(term) || 
      item.email.toLowerCase().includes(term) 
    );
  }, [filteredUsers, searchTerm]);
  
  // Pagination calculations
  const totalPages = Math.ceil(filteredDataPagination.length / itemsPerPage);
  const currentItems = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredDataPagination.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredDataPagination, currentPage, itemsPerPage]);
  
  // Reset to first page when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);

  
  // Highlight text if it matches search term
  const highlightText = (text, term) => {
    if (!term.trim() || !text) return text;

    const lowerText = text.toLowerCase();
    const lowerTerm = term.toLowerCase();

    if (!lowerText.includes(lowerTerm)) return text;

    const startIndex = lowerText.indexOf(lowerTerm);
    const endIndex = startIndex + term.length;

    return (
      <>
        {text.substring(0, startIndex)}
        <span className="bg-yellow-300 text-black font-medium rounded">
          {text.substring(startIndex, endIndex)}
        </span>
        {text.substring(endIndex)}
      </>
    );
  };
  console.log(networkStatus,'networkStatus')
  const handlelogout=()=>{
    localStorage.clear()
    navigate('/')
  }

  useEffect(()=>{
    const userData = localStorage.getItem('accessToken');
if(!userData){
  return navigate('/')
}

  },[])



  const [appliedFilter, setAppliedFilter] = useState(null);

  useEffect(() => {
    if (startDate && endDate) {
    
      const startTimestamp = zeroHourTimestampFromTimestampHelper(new Date(startDate).getTime());
      const endTimestamp =zeroHourTimestampFromTimestampHelper(new Date(endDate).getTime())+86399*1000 ;
      setStartDate(null)
      setEndDate(null)
      fetchUsers(startTimestamp,endTimestamp)
      getAlloverAllDashboardDetails(startTimestamp,endTimestamp)
      // setAppliedFilter({
      //   startDate,
      //   endDate,
      //   startTimestamp,
      //   endTimestamp,
      //   updatedAt: new Date().toISOString()
      // });
    }
  }, [startDate, endDate]);


 
  const handleReset = () => {
    setStartDate('');
    setEndDate('');
    setAppliedFilter(null);
  };
 const [isLoading,setLoadingExportData]=useState(false)
 const exportData = async () => {
  try {
    setLoadingExportData(true);
    
    // Prepare the data for export
    const jsonData = filteredUsers.map((user,index) => ({
      Rank:((currentPage - 1) * itemsPerPage) + index + 1,
      UserId:user?.userId,
      Name: user?.name || '',
      Email: user?.email || '',
      "Unique Code": user?.uniqueCode || '',
      Phone: user?.phone || '',
    }));

    // Convert data to worksheet
    const ws = XLSX.utils.json_to_sheet(jsonData);
    
    // Set column widths (in characters)
    const colWidths = [
      { wch: 20 }, // Name
      { wch: 25 }, // Email
      { wch: 15 }, // Unique Code
      { wch: 15 }, // State
      { wch: 15 }, // City
      { wch: 15 }, // Phone
      { wch: 20 }, // Date
      { wch: 10 }  // Time
    ];
    
    ws['!cols'] = colWidths;
    
    // Create workbook and add the worksheet
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'UsersData');
    
    // Save the file
    XLSX.writeFile(wb, `Users_List.xlsx`);
    
  } catch (error) {
    console.error('Export failed:', error);
    toast.error('Failed to export data');
  } finally {
    setLoadingExportData(false);
  }
};


  return (
    <>
    <style>
      {`
      
      td{
      white-space:nowrap;
      }
      `}
    </style>
    <div
      className={`${theme} min-h-screen bg-gradient-to-br from-black to-slate-900 text-slate-100 relative overflow-hidden`}
    >
      {/* Background particle effect */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full opacity-30"
      />

      <div className="max-w-screen-2xl mx-auto p-4 relative z-10">
        {/* Header */}
        <header className="flex items-center justify-between py-4 border-b border-slate-700/50 mb-6">
          <div className="flex items-center space-x-2">
            <span className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              KF Predict & Win
            </span>
          </div>
        </header>

        {/* Main content */}
        <div className="grid grid-cols-12 gap-6">
          {/* Sidebar */}
         <Sidebar/>

          {/* Main dashboard */}
          <div className="col-span-12 md:col-span-8 lg:col-span-9">
            <div className="grid gap-6">
              {/* System overview */}
              <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm overflow-hidden">
                <CardHeader className="border-b border-slate-700/50 pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-slate-100 flex items-center">
                      <Activity className="mr-2 h-5 w-5 text-cyan-500" />
                      List of Users
                    </CardTitle>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-slate-400"
                      ></Button>
                    </div>
                  </div>
                </CardHeader>

                {/* Search bar */}
               
                {/*  */}


                <CardContent className="">
                <div className=" mt-5 p-2 rounded-lg shadow-md">
      <div className="flex justify-end  items-center">
     

        <div className="">
          <Button onClick={exportData} disabled={isLoading} >
            {
              isLoading?(
                <>
                 Exporting...
                </>
              ):(
                <>
                    <Download/>
            
            Export Excel
                </>
              )
            }
    
          </Button>
        </div>
        </div>
        
{/*       
      <div className="flex space-x-3 mb-6">
      
        
        <button
          onClick={handleReset}
          className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
        >
          Reset
        </button>
      </div> */}
      
      {/* {appliedFilter && (
        <div className="p-4 bg-gray-50 rounded-md border border-gray-200">
          <h3 className="font-medium text-gray-800 mb-2">Applied Filter Details</h3>
          <div className="space-y-1 text-sm text-gray-600">
            <p><span className="font-medium">Start Date:</span> {appliedFilter.startDate}</p>
            <p><span className="font-medium">Start Timestamp:</span> {appliedFilter.startTimestamp}</p>
            <p><span className="font-medium">End Date:</span> {appliedFilter.endDate}</p>
            <p><span className="font-medium">End Timestamp:</span> {appliedFilter.endTimestamp}</p>
            <p><span className="font-medium">Applied At:</span> {appliedFilter.appliedAt}</p>
          </div>
        </div>
      )} */}
    </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-5">
                
                    <MetricCard
                      title="Prematch User List"
                      value={filteredUsers.length}
                      icon={Wifi}
                      trend="down"
                      color="blue"
                      // detail="1.2 GB/s | 42ms"
                      isPercentage={true}
                    />
                    {/* <MetricCard
                      title="Repeat Users"
                      value={networkStatus?.repeatUsers}
                      icon={Wifi}
                      trend="down"
                      color="blue"
                      // detail="1.2 GB/s | 42ms"
                      isPercentage={true}
                    />
                     <MetricCard
                      title="Total Cross City Users"
                      value={networkStatus?.crossCityUsers}
                      icon={Wifi}
                      trend="down"
                      color="blue"
                      // detail="1.2 GB/s | 42ms"
                      isPercentage={true}
                    /> */}
                  </div>

                  <div className=" mt-5">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <Input
                      type="text"
                      placeholder="Search users by name..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 bg-slate-800/50 border-slate-700 text-slate-100 placeholder:text-slate-400"
                    />
                    {isSearching && searchTerm && (
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                        <div className="text-xs text-cyan-400">
                          {searchResults.length > 0
                            ? `Found on page ${currentPage}`
                            : "Searching..."}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
  
  {/* start and end date */}


                  <div className="mt-4">
                    {/* TABLE START */}
                    <div className="">
                      {/* Table for large screens */}
                      <div className="overflow-x-auto hidden xl:block">
                        <table className="w-full text-sm text-left backdrop-blur-md bg-slate-800/30 border border-slate-700/50 rounded-lg overflow-hidden">
                          <thead className="text-sm uppercase bg-slate-700/50 text-slate-300">
                            <tr>
                            <th className="px-6 py-3">Rank</th>
                            <th className="px-6 py-3">User Id</th>


                              <th className="px-6 py-3">Name</th>
                              <th className="px-6 py-3">Email</th>
                              <th className="px-6 py-3">Code</th>
                              <th className="px-6 py-3">Phone</th>
                            </tr>
                          </thead>
                          <tbody>
                            {loading ? (
                              <tr>
                                <td
                                  colSpan="7"
                                  className="px-6 py-8 text-center text-slate-400"
                                >
                                  Loading users...
                                </td>
                              </tr>
                            ) : error ? (
                              <tr>
                                <td
                                  colSpan="7"
                                  className="px-6 py-8 text-center text-red-400"
                                >
                                  {error}
                                </td>
                              </tr>
                            ) : filteredDataPagination.length === 0 ? (
                              <tr>
                                <td
                                  colSpan="7"
                                  className="px-6 py-8 text-center text-slate-400"
                                >
                                  No users found
                                </td>
                              </tr>
                            ) : (
                              currentItems?.map((user, index) => (
                                <tr
                                  key={index}
                                  className="border-t border-slate-700/50 hover:bg-slate-700/20 transition"
                                >
                                  <td className="px-6 py-4 text-slate-200">
                                  {((currentPage - 1) * itemsPerPage) + index + 1}

                                  </td>
                                  <td className="px-6 py-4 text-slate-300">
                                    {user.userId}
                                  </td>
                                  <td className="px-6 py-4 text-slate-200">
                                    {highlightText(user.name, searchTerm)}
                                  </td>
                                  <td className="px-6 py-4 text-slate-300">
                                    {user.email}
                                  </td>
                                
                                  <td className="px-6 py-4 text-slate-300">
                                    {user.uniqueCode}
                                  </td>
                                 
                                  <td className="px-6 py-4 text-slate-300">
                                    {user.phone}
                                  </td>
                                
                                
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>

                      {/* Card layout for small screens */}
                      <div className="xl:hidden space-y-4">
                        {loading ? (
                          <div className="backdrop-blur-md bg-slate-800/30 border border-slate-700/50 rounded-lg p-4 text-center text-slate-400">
                            Loading users...
                          </div>
                        ) : error ? (
                          <div className="backdrop-blur-md bg-slate-800/30 border border-slate-700/50 rounded-lg p-4 text-center text-red-400">
                            {error}
                          </div>
                        ) : filteredUsers.length === 0 ? (
                          <div className="backdrop-blur-md bg-slate-800/30 border border-slate-700/50 rounded-lg p-4 text-center text-slate-400">
                            No users found
                          </div>
                        ) : (
                          filteredUsers.map((user, index) => (
                            <div
                              key={index}
                              className="backdrop-blur-md bg-slate-800/30 border border-slate-700/50 rounded-lg p-4 space-y-2"
                            >

<p className="text-slate-300">
                                <span className="font-semibold">Rank:</span>{" "}
                                {((currentPage - 1) * itemsPerPage) + index + 1}

                              </p>

                               <p className="text-slate-300">
                                <span className="font-semibold">user id:</span>{" "}
                                {user.userId}
                              </p>
                              <p className="text-slate-200">
                                <span className="font-semibold">Name:</span>{" "}
                                {highlightText(user.name, searchTerm)}
                              </p>
                              <p className="text-slate-300">
                                <span className="font-semibold">Email:</span>{" "}
                                {user.email}
                              </p>
                              <p className="text-slate-300">
                                <span className="font-semibold">Code:</span>{" "}
                                {user.uniqueCode}
                              </p>
                           
                              <p className="text-slate-300">
                                <span className="font-semibold">Phone:</span>{" "}
                                {user.phone}
                              </p>
                          
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                    {/* TABLE END */}
                  </div>
                  <div className="mt-6 flex flex-col items-center space-y-4">
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          setCurrentPage((prev) => Math.max(prev - 1, 1))
                        }
                        disabled={currentPage <= 1 || loading}
                        className="border-slate-700 text-slate-300 hover:bg-slate-700/50"
                      >
                        Previous
                      </Button>

                      <div className="flex items-center space-x-1">
                        {renderPaginationButtons()}
                      </div>

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          setCurrentPage((prev) =>
                            prev < totalPages ? prev + 1 : prev
                          )
                        }
                        disabled={currentPage >= totalPages || loading}
                        className="border-slate-700 text-slate-300 hover:bg-slate-700/50"
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                </CardContent>

              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}

// Component for nav items
function NavItem({ icon: Icon, label, active }) {
  return (
    <Button
      variant="ghost"
      className={`w-full justify-start ${
        active
          ? "bg-slate-800/70 text-cyan-400"
          : "text-slate-400 hover:text-slate-100"
      }`}
    >
      <Icon className="mr-2 h-4 w-4" />
      {label}
    </Button>
  );
}

// Component for metric cards
function MetricCard({
  title,
  value,
  icon: Icon,
  trend,
  color,
  detail,
  isPercentage,
}) {
  const getColor = () => {
    switch (color) {
      case "cyan":
        return "from-cyan-500 to-blue-500 border-cyan-500/30";
      case "green":
        return "from-green-500 to-emerald-500 border-green-500/30";
      case "blue":
        return "from-blue-500 to-indigo-500 border-blue-500/30";
      case "purple":
        return "from-purple-500 to-pink-500 border-purple-500/30";
      default:
        return "from-cyan-500 to-blue-500 border-cyan-500/30";
    }
  };

  const getTrendIcon = () => {
    switch (trend) {
      case "up":
        return <BarChart3 className="h-4 w-4 text-amber-500" />;
      case "down":
        return <BarChart3 className="h-4 w-4 rotate-180 text-green-500" />;
      case "stable":
        return <LineChart className="h-4 w-4 text-blue-500" />;
      default:
        return null;
    }
  };

  return (
    <div
      className={`bg-slate-800/50 rounded-lg border ${getColor()} p-4 relative overflow-hidden`}
    >
      <div className="flex items-center justify-between mb-2">
        <div className="text-sm text-slate-400">{title}</div>
        <Icon className={`h-5 w-5 text-${color}-500`} />
      </div>
      <div className="text-2xl font-bold mb-1 bg-gradient-to-r bg-clip-text text-transparent from-slate-100 to-slate-300">
        {value}
        {isPercentage ? "" : ""}
      </div>
      <div className="text-xs text-slate-500">{detail}</div>
      <div className="absolute bottom-2 right-2 flex items-center">
        {getTrendIcon()}
      </div>
      <div className="absolute -bottom-6 -right-6 h-16 w-16 rounded-full bg-gradient-to-r opacity-20 blur-xl from-cyan-500 to-blue-500"></div>
    </div>
  );
}
